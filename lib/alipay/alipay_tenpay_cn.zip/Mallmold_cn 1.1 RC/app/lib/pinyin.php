<?php
/*
*	@pinyin.php
*	Copyright (c)2013 Mallmold Ecommerce(HK) Limited. 
*	http://www.mallmold.com/
*	
*	This program is free software; you can redistribute it and/or
*	modify it under the terms of the GNU General Public License
*	as published by the Free Software Foundation; either version 2
*	of the License, or (at your option) any later version.
*	More details please see: http://www.gnu.org/licenses/gpl.html
*	
*	If you want to get an unlimited version of the program or want to obtain
*	additional services, please send an email to <service@mallmold.com>.
*/

class pinyin
{
	private $data = '';
	
	public function firstname($name)
    {
		$words = $this->words($name);
		preg_match_all('/[A-Z][a-z]{1,}/', $words, $matchs);
		$names = $matchs[0];
		$n = count($names);
		if($n > 3){
			return $names[0].$names[1];
		}else{
			return $names[0];
		}
	}
	
	public function lastname($name)
    {
		$words = $this->words($name);
		preg_match_all('/[A-Z][a-z]{1,}/', $words, $matchs);
		$names = $matchs[0];
		$n = count($names);
		$start = $n > 3 ? 2 : 1;
		$str = '';
		while($names[$start]){
			$str .= $names[$start];
			$start++;
		}
		return $str;
	}
	
	public function word($word)
    {
		$word = trim($word);
		if(!$word){
			return null;
		}
		
		$this->getdata();
		if(!$this->data){
			return $word;
		}
		$n = strpos($this->data, $word);
		if($n > 0){
			$l = mb_strlen($word);
			$k = $n + $l + 2;
			$m = 1;
			$py = '';
			while($this->data[$k] != "\r" && $m < 8){
				$py .= $this->data[$k];
				$k++;
				$m++;
			}
			return $py;
		}else{
			return $word;
		}
	}
	
	public function words($words)
    {
		$words = iconv('UTF-8', 'GBK', $words);
		$len = mb_strlen($words);
		if($len < 1){
			return null;
		}
		
		$str = '';
		$n = 0;
		while($n <= $len){
			$word = mb_substr($words, $n, 1);
			if($word){
				$py = $this->word($word);
				if($py){
					$str .= ucfirst($py);
				}
			}
			$n++;
		}
		return $str;
	}
	
	private function getdata()
    {
		if(!$this->data){
			$file = dirname(__FILE__).'/pinyin.csv';
			$this->data = iconv('UTF-8', 'GBK', file_get_contents($file));
		}
	}
}
?>