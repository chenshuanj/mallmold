<?php
return array(
	//base
	'SHOW_ERROR' => 1,
	'TIME_LIMIT' => 0,
	'TIMEZONE' => 'PRC',
	
	//control
	'TPL_NAME' => 'default',
	'LAN_NAME' => 'zh_cn',
);
?>