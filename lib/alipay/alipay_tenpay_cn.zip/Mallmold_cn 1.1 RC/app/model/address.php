<?php
/*
*	@address.php
*	Copyright (c)2013 Mallmold Ecommerce(HK) Limited. 
*	http://www.mallmold.com/
*	
*	This program is free software; you can redistribute it and/or
*	modify it under the terms of the GNU General Public License
*	as published by the Free Software Foundation; either version 2
*	of the License, or (at your option) any later version.
*	More details please see: http://www.gnu.org/licenses/gpl.html
*	
*	If you want to get an unlimited version of the program or want to obtain
*	additional services, please send an email to <service@mallmold.com>.
*/

class address extends model
{
	public function address_list()
	{
		$user_id = $_SESSION['user_id'];
		$list = $this->db->table('user_address')->where("user_id=$user_id")->getlist();
		foreach($list as $k=>$v){
			$list[$k]['country'] = $this->model('region')->get_country_name($v['country_id']);
			$list[$k]['state'] = $this->model('region')->get_region_name($v['region_id']);
		}
		return $list;
	}
	
	public function get_address($id)
	{
		return $this->db->table('user_address')->where("id=$id")->get();
	}
	
	public function save_address(array $data, $id=0)
	{
		$address = array(
			'user_id' => $_SESSION['user_id'],
			'fullname' => trim($data['fullname']),
			'country_id' => intval($data['country_id']),
			'region_id' => intval($data['region_id']),
			'city' => trim($data['city']),
			'address' => trim($data['address']),
			'phone' => trim($data['phone']),
			'postcode' => trim($data['postcode'])
		);
		foreach($address as $k=>$v){
			if(!$v){
				return false;
			}
		}
		
		if($id > 0){
			$this->db->table('user_address')->where("id=$id")->update($address);
			return $id;
		}else{
			return $this->db->table('user_address')->insert($address);
		}
	}
	
	public function del_address($id)
	{
		return $this->db->table('user_address')->where("id=$id")->delete();
	}
}
?>