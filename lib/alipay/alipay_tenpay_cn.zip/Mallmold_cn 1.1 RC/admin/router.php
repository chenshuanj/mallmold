<?php
return array (
	'type' => 0,
	'*/*' => array (
		'scheme' => 'http',
		'host' => '',
		'query' => '',
		'rewrite' => '',
	),
	'admin/login' => array (
		'scheme' => 'http',
	),
	'admin/dologin' => array (
		'scheme' => 'http',
	),
)
?>