<?php
define('UPDATE', '20131010');
define('VERSION', '1.0 RC');
?>